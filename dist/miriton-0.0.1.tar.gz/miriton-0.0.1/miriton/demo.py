def sayhello():
    print("Je suis merlon merloville le fragile")